infochimps <-
function(api.key)
    structure(list(api.key=api.key,
                    base="http://api.infochimps.com/soc/net/tw/",
                    de="http://api.infochimps.com/web/an/de/",
                    ip="http://api.infochimps.com/web/an/ip_census/"),
    class="infochimps")

